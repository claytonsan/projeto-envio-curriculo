
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="accordion accordion-flush" id="accordionFlushExample">
            <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingOne">
                    <a href="/" class="btn bg-navy margin pull-right" > </i> Tela de Cadastro</a>
                    <a href="/curriculo_cadastrado" class="btn bg-navy margin pull-right" > </i> Curriculos Cadastrados</a><br>
                </h2>
            </div>
          </div>
        <div class="card text-center">
            <div class="card-header">
                <h3 class="box-title">Curriculos Cadastrados</h3>
            </div>
            <div class="container">
                <div class="row">
                    <div class="one-third column">
                        <table class="table table-striped">
                            <thead>
                                <th>#</th>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>Telefone</th>
                                <th>Cargo Pretendido</th>
                                <th>Escolaridade</th>
                                <th>Observações</th>
                                <th>Curriculo</th>
                                <th>Data Candidatura</th>
                            </thead>
                            <tbody>
                                @foreach ($candidatos as $candidato)
                                    <tr>
                                        <td>{{isset($candidato->id) ? $candidato->id : ''}}</td>
                                        <td>{{isset($candidato->nome) ? $candidato->nome : ''}}</td>
                                        <td>{{isset($candidato->email) ? $candidato->email : ''}}</td>
                                        <td>{{isset($candidato->telefone) ? $candidato->telefone : ''}}</td>
                                        <td>{{isset($candidato->cargo) ? $candidato->cargo : ''}}</td>
                                        <td>{{isset($escolaridade[$candidato->escolaridade]) ? $escolaridade[$candidato->escolaridade] : ''}}</td>
                                        <td>{{isset($candidato->observacoes) ? $candidato->observacoes : ''}}</td>
                                        <td><a href='{{$candidato->filepath}}' target="_blank"><i class="fa fa-paperclip"></i> Curriculo</a></td>
                                        <td>{{isset($candidato->created_at) ? date_create($candidato->created_at)->format('d-m-Y')  : ''}}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
