<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="accordion accordion-flush" id="accordionFlushExample">
            <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingOne">
                    <a href="/" class="btn bg-navy margin pull-right" > </i> Tela de Cadastro</a>
                    <a href="/curriculo_cadastrado" class="btn bg-navy margin pull-right" > </i> Curriculos Cadastrados</a>
                </h2>
            </div>
          </div>
        <div class="card text-center">
            <div class="card-header">
                <h3 class="box-title">Envio de Curriculo</h3>
            </div>
            <div class="container">
                <div class="row">
                    <div class="one-third column">
                        <form id="form_cadastro_curriculo" role="form">
                            @csrf
                            <br>
                            <div class="input-group mb-3">
                                <span class="input-group-text" id="basic-addon1">Nome Completo(*)</span>
                                <input type="text" class="form-control nome"  id="nome" name="nome">
                            </div>
                            <div class="input-group mb-3">
                                <input type="email" class="form-control email" id="email" name="email" placeholder="E-mail(*)" >
                                <span class="input-group-text" id="basic-addon2">@exemplo.com</span>
                            </div>
                            <div class="input-group">
                                {{ Form::select('escolaridade', $escolaridade, null, ['class'=>'select2 form-control escolaridade','style'=>'width:100%'])}}
                            </div>
                            <br>
                            <div class="input-group mb-3">
                                <span class="input-group-text">Cargo Pretendido(*)</span>
                                <input type="text" class="form-control cargo" name="cargo" id="cargo">
                                <span class="input-group-text">Telefone(*)</span>
                                <input type="number" class="form-control telefone" name="telefone" id="telefone">
                            </div>
                            <div class="input-group mb-3">
                                <input type="file" class="form-control" id="filepath"  name="filepath">
                                <label class="input-group-text" for="filepath">Upload(*)</label>
                            </div>
                            <div class="input-group">
                                <span class="input-group-text">Observações </span>
                                <textarea class="form-control observacoes" aria-label="observacoes"  id="observacoes"  name="observacoes"></textarea>
                            </div>
                            <br>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-flat btn-success pull-right" id="bt_salvar"> </i> Salvar</button>
                            </div>
                            <br>
                        </form>
                        <div class="card-footer text-muted">
                            Campos Obrigatórios (*)
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
        <script>
        $(function () {

            //Metodo que valida o tamanho do curriculo imputado no sistema
            var filepath = document.getElementById("filepath");
            filepath.addEventListener("change", function(e) {
                var size = filepath.files[0].size;
                if(size < 1048576) { //1MB
                    alert('Arquivo imputado no sistema'); //Dentro do permitido
                } else {
                    alert("O tamanho máximo do arquivo é de 1MB"); //Excede o permitido
                }
                e.preventDefault();
            });

            //Botão de salvar candidato.

            $("#bt_salvar").click(function (e) {
                e.preventDefault();
                $("#bt_salvar").attr('disabled', true);
                var form = $('#form_cadastro_curriculo')[0];
                var data = new FormData(form);
                var nome = $(".nome").val();
                var telefone = $(".telefone").val();
                var email = $(".email").val();
                var escolaridade = $(".escolaridade").val();
                var cargo = $(".cargo").val();
                var file = $("#filepath").val();
                var flag_file           = false;

                //valida formato do arquivo e se os campos obrigatórios foram preenchidos.

                if((file.substring(file.length -4,file.length) != ".doc") && (file.substring(file.length -5,file.length) != ".docx") && (file.substring(file.length -4,file.length) != ".pdf")){
                    alert("Formato do arquivo não compativel, inclua um arquivo .doc, .docx ou .pdf ");
                    $('#filepath').val("");
                    $("#bt_salvar").attr('disabled', false);
                }else if((nome == '') || (nome == null)){
                    alert('Favor informa seu nome');
                    $("#bt_salvar").attr('disabled', false);
                }else if((telefone == '') || (telefone == null)){
                    alert('Favor informa seu telefone');
                    $("#bt_salvar").attr('disabled', false);
                }else if(escolaridade == 0){
                    alert('Favor informa sua escolaridade');
                    $("#bt_salvar").attr('disabled', false);
                }else if((email == '') || (email == null)){
                    alert('Favor informa seu email');
                    $("#bt_salvar").attr('disabled', false);
                }else if((cargo == '') || (cargo == null)){
                    alert('Favor informa seu cargo desejado');
                    $("#bt_salvar").attr('disabled', false);
                }else if((file == '') || (file == null)){
                    alert('Favor Anexar seu Curriculo');
                    $("#bt_salvar").attr('disabled', false);
                }else{
                    flag_file = true;
                }
                if(flag_file == true ){
                    $.ajax({
                        type: "POST",
                        enctype: 'multipart/form-data',
                        url: "/envio_curriculo",
                        data: data,
                        processData: false, // impedir que o jQuery tranforma a "data" em querystring
                        contentType: false, // desabilitar o cabeçalho "Content-Type"
                        cache: false, // desabilitar o "cache"
                        timeout: 600000, // definir um tempo limite (opcional)
                        success: function (data) {
                            if(data['success']){
                                alert('Cadastro efetuado com sucesso!');
                                location.reload();
                            }
                        },
                        error: function (e) {
                            console.log(e);
                            $("#bt_salvar").attr('disabled', false);
                        }
                    })
                }
            });
        })
        </script>
    </body>
</html>
