<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\EscolaridadeService;
use App\Services\FormularioService;


class HomeController extends Controller
{
    // Metodo utilizado para formar a visualização da tela de Cadastro
    public function index()
    {
        $Escolaridade = new EscolaridadeService();
        $data['escolaridade'] = ['0' => 'Selecione uma Escolaridade'] + $Escolaridade->buscarEscolaridadeDescricao();
        return view('tela_inicial',$data);
    }

    public function create()
    {
        //
    }

    // Metodo utilizado para salvar as informações enviadas da tela de cadastro

    public function store(Request $request)
    {
        $dados = $request->all();
        $Formulario = new FormularioService();
        $Formulario->salvarFormulario($dados);
        $data['success'] = true;
        return response()->json(['success' => true], 200);
    }


    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }

    // Controller da View (tela_formularios) onde é formado o formulario com todos os candidatos

    public function lista_curriculos()
    {
        $FormularioService      = new FormularioService();
        $Escolaridade           = new EscolaridadeService();
        $data['candidatos']     = $FormularioService->buscarFormularios();
        $data['escolaridade']   = $Escolaridade->buscarEscolaridadeDescricao();
        return view('tela_formularios',$data);
    }

}
