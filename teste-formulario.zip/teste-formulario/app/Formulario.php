<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Formulario extends Model
{
    use SoftDeletes;
    protected $table = 'formulario';
    protected $fillable = [
        'id', 'nome', 'email','telefone', 'cargo' ,'escolaridade' ,'observacoes','filepath','ip_usuario','created_by' ,'updated_by' ,'deleted_by' ,'created_at' ,'updated_at' ,'deleted_at'
    ];
    protected $dates = ['deleted_at'];
}
