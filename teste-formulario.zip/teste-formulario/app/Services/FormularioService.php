<?php

namespace App\Services;

use Illuminate\Support\Str;
use App\Formulario;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use App\Services\EscolaridadeService;


class FormularioService {

    // Metodo que retorna todos os formularios salvos no banco

    public function buscarFormularios()
    {
        $formularios = Formulario::all();
        if($formularios){
            return $formularios;
        }else{
            return false;
        }
    }

    // Metodo que retorna o IP do candidato para salvar no banco

    function get_client_ip() {
        $ipaddress = '';
        if (isset($_SERVER['HTTP_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_X_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if(isset($_SERVER['REMOTE_ADDR']))
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }

    // Metodo utilizado para salvar o formulario e mandar um email para o candidato com as informações preenchidas e seu curriculo

    public function salvarFormulario($parametros)
    {
        $EscolaridadeService = new EscolaridadeService();
        $data['escolaridade'] = $EscolaridadeService->buscarEscolaridadeDescricao();
        Session::put('escolaridade', $data['escolaridade']);
        $path = public_path();
        $file = $parametros['filepath'];
        $filename = Str::random(6) . '_' . str_replace(" ", "_", preg_replace("/&([a-z])[a-z]+;/i", "$1", htmlentities(trim($file->getClientOriginalName()))));
        $file->move($path . '/curriculos', $filename);
        $filepath = '/curriculos/' . $filename;
        $params['filepath'] 	= $filepath;
        $params['nome'] 	    = $parametros['nome'];
        $params['telefone'] 	= $parametros['telefone'];
        $params['email'] 	    = $parametros['email'];
        $params['cargo'] 	    = $parametros['cargo'];
        $params['escolaridade'] = $parametros['escolaridade'];
        $params['observacoes'] 	= $parametros['observacoes'];
        $params['ip_usuario'] 	= $this->get_client_ip();
        $params['created_at']   = date('Y-m-d H:i:s');
        $params['updated_at']   = date('Y-m-d H:i:s');
        $formulario = Formulario::insert($params);
        $para = $parametros['email'];
        $nome_candidato = $parametros['nome'];
        Session::put('params', $params);
        Mail::send('Email.email_candidato',$params, function ($message) use ($para,$nome_candidato,$filepath) {
            $message->from('conta.clayton.teste@gmail.com')
                ->to($para)
                ->attach(public_path().$filepath)
                ->subject('Recebemos seu Curriculo '.$nome_candidato);
        });
        if ($formulario) {
            return $formulario;
        } else {
            return false;
        }
    }

}
