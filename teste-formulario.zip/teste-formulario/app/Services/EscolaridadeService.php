<?php

namespace App\Services;

use App\Escolaridade;

class EscolaridadeService {

    // Metodo que retorna a descrição da escolaridade com seu ID

    public function buscarEscolaridadeDescricao()
    {
        $escolaridade = Escolaridade::pluck('descricao', 'id')->toArray();
        if($escolaridade){
            return $escolaridade;
        }else{
            return false;
        }
    }

}
