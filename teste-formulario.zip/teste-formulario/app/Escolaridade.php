<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Escolaridade extends Model
{
    use SoftDeletes;
    protected $table = 'escolaridade';
    protected $fillable = [
        'id', 'descricao','created_by' ,'updated_by' ,'deleted_by' ,'created_at' ,'updated_at' ,'deleted_at'
    ];
    protected $dates = ['deleted_at'];
}
