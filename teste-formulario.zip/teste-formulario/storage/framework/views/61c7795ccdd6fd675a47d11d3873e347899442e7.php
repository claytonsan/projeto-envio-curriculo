
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="accordion accordion-flush" id="accordionFlushExample">
            <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingOne">
                    <a href="/" class="btn bg-navy margin pull-right" > </i> Tela de Cadastro</a>
                    <a href="/curriculo_cadastrado" class="btn bg-navy margin pull-right" > </i> Curriculos Cadastrados</a><br>
                </h2>
            </div>
          </div>
        <div class="card text-center">
            <div class="card-header">
                <h3 class="box-title">Curriculos Cadastrados</h3>
            </div>
            <div class="container">
                <div class="row">
                    <div class="one-third column">
                        <table class="table table-striped">
                            <thead>
                                <th>#</th>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>Telefone</th>
                                <th>Cargo Pretendido</th>
                                <th>Escolaridade</th>
                                <th>Observações</th>
                                <th>Curriculo</th>
                                <th>Data Candidatura</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(isset($candidato->id) ? $candidato->id : ''); ?></td>
                                        <td><?php echo e(isset($candidato->nome) ? $candidato->nome : ''); ?></td>
                                        <td><?php echo e(isset($candidato->email) ? $candidato->email : ''); ?></td>
                                        <td><?php echo e(isset($candidato->telefone) ? $candidato->telefone : ''); ?></td>
                                        <td><?php echo e(isset($candidato->cargo) ? $candidato->cargo : ''); ?></td>
                                        <td><?php echo e(isset($escolaridade[$candidato->escolaridade]) ? $escolaridade[$candidato->escolaridade] : ''); ?></td>
                                        <td><?php echo e(isset($candidato->observacoes) ? $candidato->observacoes : ''); ?></td>
                                        <td><a href='<?php echo e($candidato->filepath); ?>' target="_blank"><i class="fa fa-paperclip"></i> Curriculo</a></td>
                                        <td><?php echo e(isset($candidato->created_at) ? date_create($candidato->created_at)->format('d-m-Y')  : ''); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\WWW\teste-formulario\resources\views/tela_formularios.blade.php ENDPATH**/ ?>