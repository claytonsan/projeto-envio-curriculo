<html>

    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        th, td {
            padding: 5px;
            text-align: left;
        }
    </style>

    <table style="border: 1px solid black;">
        <thead>
            <th style="padding: 5px;">Nome</th>
            <th style="padding: 5px;">E-mail</th>
            <th style="padding: 5px;">Telefone</th>
            <th style="padding: 5px;">Cargo</th>
            <th style="padding: 5px;">Escolaridade</th>
            <th style="padding: 5px;">Observações</th>
        </thead>
        <tbody>
            <tr>
                <?php if(Session::has('params')): ?>
                    <?php $escolaridade = Session::get('escolaridade');  ?>
                    <td><?php echo e(Session::get('params')['nome']); ?></td>
                    <td><?php echo e(Session::get('params')['email']); ?></td>
                    <td><?php echo e(Session::get('params')['telefone']); ?></td>
                    <td><?php echo e(Session::get('params')['cargo']); ?></td>
                    <td><?php echo e($escolaridade[Session::get('params')['escolaridade']]); ?></td>
                    <td><?php echo e(Session::get('params')['observacoes']); ?></td>
                <?php endif; ?>
            </tr>
        </tbody>
    </table>
    <br>

    </body>
</html>
<?php /**PATH C:\WWW\teste-formulario\resources\views/Email/email_candidato.blade.php ENDPATH**/ ?>